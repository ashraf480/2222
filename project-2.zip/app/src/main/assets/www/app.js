/* 90 يوم تغيير — منطق التطبيق */
(function () {
  'use strict';

  const DAYS = 90, PAGE = 30, PAGES = 3;
  const KEY = 'baqi90.v1';
  const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
  const ar = (n) => String(n).replace(/\d/g, (d) => AR_DIGITS[d]);
  const WEEK = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const HMONTHS = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];

  /* ---------- التاريخ ---------- */
  const pad = (n) => (n < 10 ? '0' : '') + n;
  const iso = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const parseISO = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (d, n) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() + n); return x; };
  const today0 = () => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()); };
  const diffDays = (a, b) => Math.round((a - b) / 86400000);

  let hfmt = null;
  try { hfmt = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'numeric', year: 'numeric' }); } catch (e) { hfmt = null; }
  function hijri(d) {
    if (!hfmt) return null;
    try {
      const o = {};
      hfmt.formatToParts(addDays(d, S.hadj || 0)).forEach((p) => { if (p.type === 'day' || p.type === 'month' || p.type === 'year') o[p.type] = parseInt(p.value, 10); });
      if (!o.day || !o.month) return null;
      return o;
    } catch (e) { return null; }
  }

  /* ---------- الحالة ---------- */
  const safeGet = () => { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } };
  let S = safeGet() || { start: null, c: {}, t: {}, h: {}, n: {}, hadj: 0 };
  S.c = S.c || {}; S.t = S.t || {}; S.h = S.h || {}; S.n = S.n || {}; S.hadj = S.hadj || 0;
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* ignore */ } };
  if (!safeGet()) save();

  /* ---------- شجرة المربعات ---------- */
  const days = (id, title, hint) => ({ id, title, hint, type: 'days' });
  const TREE = [
    { id: 'salah', title: 'الصلاة', icon: '🕌', children: [
      days('fajr', 'صلاة الفجر'), days('dhuhr', 'صلاة الظهر'), days('asr', 'صلاة العصر'),
      days('maghrib', 'صلاة المغرب'), days('isha', 'صلاة العشاء'),
      { id: 'sunan', title: 'سنن الصلاة', children: [
        days('s_fajr', 'سنة الفجر'), days('s_dhuhr', 'سنة الظهر', '٦ ركعات'), days('s_asr', 'سنة العصر', '٤ ركعات قبلية'),
        days('s_maghrib', 'سنة المغرب'), days('s_isha', 'سنة العشاء')] },
      days('witr', 'صلاة الشفع والوتر'), days('qiyam', 'صلاة قيام الليل'), days('duha', 'صلاة الضحى'),
      { id: 'tasabeeh', title: 'صلاة التسابيح', hint: 'كل يوم خميس', type: 'dates', kind: 'thu' } ] },
    { id: 'quran', title: 'القرآن الكريم', icon: '📖', children: [
      days('khatm', 'الختم'), days('tadabbur', 'التدبر', 'كل يوم آية'), days('hifz', 'الحفظ', 'كل يوم نص وجه'),
      { id: 'murajaa', title: 'المراجعة', hint: 'كل يوم اثنين وخميس', type: 'dates', kind: 'monthu' } ] },
    { id: 'hadith', title: 'الحديث الشريف', icon: '📜', type: 'hadith', hint: 'من رياض الصالحين' },
    { id: 'habits', title: 'كسر العادات', icon: '🔓', children: [
      { id: 'h1', title: 'عادة ١', type: 'habit' }, { id: 'h2', title: 'عادة ٢', type: 'habit' },
      { id: 'h3', title: 'عادة ٣', type: 'habit' }, { id: 'h4', title: 'عادة ٤', type: 'habit' } ] },
    { id: 'names', title: 'الأسماء الحسنى', icon: '✨', type: 'names' },
    { id: 'fasting', title: 'صيام النوافل', icon: '🌙', type: 'dates', kind: 'fast', hint: 'الاثنين والخميس والأيام البيض' },
    days('sleep', 'تنظيم النوم'),
    days('sadaqa', 'الصدقة ولو جنيه'),
    { id: 'dua', title: 'الدعاء', icon: '🤲', type: 'lines', pages: 3, lines: 15, ph: 'دعاء...' },
    { id: 'last', title: 'الشهر الأخير', icon: '🏁', children: [
      { id: 'goals', title: 'تحديد الأهداف', type: 'lines', pages: 1, lines: 10, ph: 'هدف...' },
      { id: 'khatmat', title: 'كم ختمة', type: 'lines', pages: 1, lines: 10, ph: 'النية لهذه الختمة...' },
      { id: 'sadaqat', title: 'كم صدقة', type: 'lines', pages: 3, lines: 10, ph: 'النية لهذه الصدقة...' },
      { id: 'rahm', title: 'صلة الرحم', type: 'lines', pages: 1, lines: 10, ph: 'النية لهذه الزيارة...' } ] },
    { id: 'calendar', title: 'التقويم الهجري', icon: '🗓️', type: 'calendar' }
  ];
  // الأيقونات الافتراضية للمربعات الرئيسية
  const ICONS = { sleep: '😴', sadaqa: '💰' };
  TREE.forEach((n) => { if (!n.icon) n.icon = ICONS[n.id] || '◻️'; });

  // ألوان: لكل مربع رئيسي درجة لون (Hue)، وكل مربع داخلي له درجة مختلفة
  const HUES = { salah: 165, quran: 40, hadith: 25, habits: 350, names: 275, fasting: 215, sleep: 235, sadaqa: 130, dua: 190, last: 12, calendar: 305 };
  (function assign(list, base) {
    list.forEach((n, i) => {
      n.h = base === null ? (HUES[n.id] != null ? HUES[n.id] : (i * 37) % 360) : (base + 20 + i * 41) % 360;
      if (n.children) assign(n.children, n.h);
    });
  })(TREE, null);

  const findNode = (path) => {
    let list = TREE, node = null;
    for (const id of path) { node = list.find((n) => n.id === id); if (!node) return null; list = node.children || []; }
    return node;
  };

  /* ---------- التواريخ الآلية ---------- */
  function dateList(kind) {
    const start = parseISO(S.start), out = [];
    for (let i = 0; i < DAYS; i++) {
      const d = addDays(start, i), w = d.getDay(), h = hijri(d);
      let ok = false, bayd = false;
      if (kind === 'thu') ok = w === 4;
      else if (kind === 'monthu') ok = w === 1 || w === 4;
      else if (kind === 'fast') {
        bayd = !!h && h.day >= 13 && h.day <= 15;
        ok = w === 1 || w === 4 || bayd;
        // لا صيام في رمضان (فرض) ولا يوم العيدين وأيام التشريق
        if (h && (h.month === 9 || (h.month === 10 && h.day === 1) || (h.month === 12 && h.day >= 10 && h.day <= 13))) ok = false;
      }
      if (ok) out.push({ i, d, h, bayd, k: iso(d) });
    }
    return out;
  }

  /* ---------- حساب التقدم ---------- */
  function counts(node) {
    if (node.children) {
      let done = 0, total = 0;
      node.children.forEach((c) => { const r = counts(c); done += r.done; total += r.total; });
      return { done, total };
    }
    let done = 0, total = 0;
    switch (node.type) {
      case 'days': case 'habit': case 'hadith':
        total = DAYS; for (let i = 0; i < DAYS; i++) if (S.c[node.id + ':' + i] === 1) done++; break;
      case 'names':
        total = NAMES.length; for (let i = 0; i < NAMES.length; i++) if (S.c['names:' + i] === 1) done++; break;
      case 'dates': {
        const l = dateList(node.kind); total = l.length;
        l.forEach((x) => { if (S.c[node.id + ':' + x.k] === 1) done++; }); break; }
      case 'lines':
        total = node.pages * node.lines;
        for (let p = 0; p < node.pages; p++) for (let l = 0; l < node.lines; l++) {
          const v = S.t[node.id + ':' + p + ':' + l]; if (v && v.trim()) done++;
        }
        break;
    }
    return { done, total };
  }
  const pct = (r) => (r.total ? Math.round((r.done * 100) / r.total) : 0);

  /* ---------- حالة التنقل ---------- */
  let nav = { path: [], page: 0, sub: null };
  let modal = null;
  const $app = document.getElementById('app');
  const $title = document.getElementById('title');
  const $back = document.getElementById('back');
  const $gear = document.getElementById('gear');
  const $modal = document.getElementById('modal');

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const bar = (p) => '<div class="bar"><i style="width:' + p + '%"></i></div>';
  const todayIndex = () => diffDays(today0(), parseISO(S.start)); // 0 = اليوم الأول

  // اسم العادة لا يظهر أبدًا على المربع أو في العناوين أو التقرير؛ يظهر فقط داخل شاشة تعديل العادة
  function habitTitle(node) { return node.title; }

  /* ---------- الشاشات ---------- */
  function renderHome() {
    const ti = todayIndex();
    let remain, sub;
    if (ti < 0) { remain = DAYS; sub = 'يبدأ التحدي بعد ' + ar(-ti) + ' يوم'; }
    else if (ti >= DAYS) { remain = 0; sub = 'انتهت الأيام الـ ٩٠ — تقبّل الله منك'; }
    else { remain = DAYS - ti; sub = 'اليوم ' + ar(ti + 1) + ' من ' + ar(DAYS); }
    let done = 0, total = 0;
    TREE.forEach((n) => { const r = counts(n); done += r.done; total += r.total; });
    const all = pct({ done, total });

    const td = today0(), th = hijri(td);
    const hd = th ? WEEK[td.getDay()] + ' ' + ar(th.day) + ' ' + HMONTHS[th.month - 1] + ' ' + ar(th.year) + 'هـ' : WEEK[td.getDay()];
    let h = '<section class="hero"><div class="hdate">' + hd + '<small>' + ar(td.getDate() + '/' + (td.getMonth() + 1) + '/' + td.getFullYear()) + 'م</small></div><div class="big">' + ar(remain) + '</div><div class="lbl">يوم متبقٍّ</div><div class="sub">' + sub + '</div>' +
      bar(all) + '<div class="small">الإنجاز الكلي ' + ar(all) + '٪</div></section><div class="grid2">';
    TREE.forEach((n) => {
      const p = pct(counts(n));
      h += '<button class="card" style="--h:' + n.h + '" data-open="' + n.id + '"><span class="ic">' + n.icon + '</span><span class="tt">' + esc(n.title) + '</span>' +
        (n.type === 'calendar' ? '<span class="pc">ملاحظات وتنبيهات</span>' : bar(p) + '<span class="pc">' + ar(p) + '٪</span>') + '</button>';
    });
    $app.innerHTML = h + '</div><button class="btn pdfbtn" id="pdfexp">📄 تصدير تقرير PDF</button>';
  }

  function renderGroup(node) {
    const r = counts(node), p = pct(r);
    let h = '<div class="sect-head">' + bar(p) + '<div class="small">التقدم ' + ar(p) + '٪ (' + ar(r.done) + ' من ' + ar(r.total) + ')</div></div><div class="list">';
    node.children.forEach((c) => {
      const cp = pct(counts(c));
      const t = c.type === 'habit' ? habitTitle(c) : c.title;
      h += '<button class="row" style="--h:' + c.h + '" data-open="' + c.id + '"><span class="rt">' + esc(t) + (c.hint ? '<small>' + esc(c.hint) + '</small>' : '') + '</span>' +
        '<span class="rp">' + ar(cp) + '٪</span>' + bar(cp) + '</button>';
    });
    $app.innerHTML = h + '</div>';
  }

  const MONTH_NAMES = ['الشهر الأول', 'الشهر الثاني', 'الشهر الثالث'];
  function tabs(n, months) {
    if (n < 2) return '';
    let h = '<div class="tabs">';
    for (let p = 0; p < n; p++) h += '<button class="tab' + (p === nav.page ? ' on' : '') + '" data-page="' + p + '">' + (months ? MONTH_NAMES[p] : 'صفحة ' + ar(p + 1)) + '</button>';
    return h + '</div>';
  }

  const cellCls = (v) => (v === 1 ? ' ok' : v === 2 ? ' no' : '');
  const cellMark = (v) => (v === 1 ? '✓' : v === 2 ? '✗' : '');

  function dayCells(id) {
    const ti = todayIndex(), start = parseISO(S.start);
    let h = '<div class="cells">';
    for (let i = nav.page * PAGE; i < Math.min(DAYS, (nav.page + 1) * PAGE); i++) {
      const k = id + ':' + i, v = S.c[k] || 0, d = addDays(start, i);
      h += '<button class="cell' + cellCls(v) + (i === ti ? ' today' : '') + '" data-k="' + k + '"><b>' + ar(i + 1) + '</b><em>' +
        ar(d.getDate() + '/' + (d.getMonth() + 1)) + '</em><span class="mk">' + cellMark(v) + '</span></button>';
    }
    return h + '</div>';
  }

  function renderDays(node) {
    $app.innerHTML = head(node) + tabs(PAGES, true) + dayCells(node.id) + legend();
  }

  function head(node) {
    const r = counts(node), p = pct(r);
    return '<div class="sect-head">' + bar(p) + '<div class="small">التقدم ' + ar(p) + '٪ (' + ar(r.done) + ' من ' + ar(r.total) + ')</div></div>';
  }
  const legend = () => '<p class="legend">اضغط على المربع: ✓ تم — ✗ لم يتم — ثم فارغ</p>';

  function renderDates(node) {
    const all = dateList(node.kind);
    const lo = nav.page * PAGE, hi = lo + PAGE;
    const list = all.filter((x) => x.i >= lo && x.i < hi);
    let h = head(node) + tabs(PAGES, true);
    if (!list.length) h += '<p class="empty">لا توجد أيام في هذه الصفحة</p>';
    h += '<div class="cells wide">';
    const ti = todayIndex();
    list.forEach((x) => {
      const k = node.id + ':' + x.k, v = S.c[k] || 0;
      const hj = x.h ? ar(x.h.day) + ' ' + HMONTHS[x.h.month - 1] : '';
      h += '<button class="cell dt' + cellCls(v) + (x.i === ti ? ' today' : '') + '" data-k="' + k + '"><b>' + WEEK[x.d.getDay()] + '</b><em>' +
        ar(x.d.getDate() + '/' + (x.d.getMonth() + 1) + '/' + x.d.getFullYear()) + '</em><em class="hj">' + hj + '</em>' +
        (x.bayd ? '<i class="tag">أيام البيض</i>' : '') + '<span class="mk">' + cellMark(v) + '</span></button>';
    });
    $app.innerHTML = h + '</div>' + legend() + (hfmt ? '<p class="legend">التاريخ الهجري تقريبي وقد يختلف يومًا بحسب الرؤية.</p>' : '');
  }

  function renderHadith(node) {
    let h = head(node) + tabs(PAGES, true) + '<div class="hlist">';
    for (let i = nav.page * PAGE; i < Math.min(DAYS, (nav.page + 1) * PAGE); i++) {
      const k = node.id + ':' + i, v = S.c[k] || 0;
      h += '<div class="hrow' + cellCls(v) + '"><span class="hn">' + ar(i + 1) + '</span><div><p>' + esc(HADITHS[i] || '') + '</p>' +
        '<button class="exb" data-ex="' + i + '">📖 شرح وتطبيق</button></div>' +
        '<button class="chk' + cellCls(v) + '" data-k="' + k + '" aria-label="تحديد">' + (cellMark(v) || '○') + '</button>' +
        '<div class="ex" hidden><h5>الشرح</h5><p>' + esc((HADITH_EX[i] || [])[0] || '') + '</p><h5>تطبيق عملي</h5><p>' + esc((HADITH_EX[i] || [])[1] || '') + '</p>' +
        '<small>مستفاد من شروح أهل السنة (النووي، ابن حجر، ابن عثيمين)</small></div></div>';
    }
    $app.innerHTML = h + '</div>' + legend();
  }

  function renderNames(node) {
    if (nav.sub != null) return renderNameDetail(node, nav.sub);
    const per = 33;
    let h = head(node) + tabs(3) + '<div class="cells names">';
    for (let i = nav.page * per; i < Math.min(NAMES.length, (nav.page + 1) * per); i++) {
      const v = S.c['names:' + i] || 0, has = (S.t['names:' + i] || '').trim();
      h += '<button class="cell nm' + cellCls(v) + '" data-name="' + i + '"><b>' + esc(NAMES[i][0]) + '</b><em>' + ar(i + 1) + '</em>' +
        (has ? '<i class="dot"></i>' : '') + '<span class="mk">' + cellMark(v) + '</span></button>';
    }
    $app.innerHTML = h + '</div><p class="legend">اضغط على الاسم لعرض معناه وكتابة ما استفدته منه.</p>';
  }

  function renderNameDetail(node, i) {
    const n = NAMES[i], v = S.c['names:' + i] || 0;
    $app.innerHTML = '<article class="detail"><div class="nm-big">' + esc(n[0]) + '</div>' +
      '<h4>المعنى</h4><p>' + esc(n[1]) + '</p><h4>كيف نتعبد لله بهذا الاسم</h4><p>' + esc(n[2]) + '</p>' +
      '<h4>ما استفدته من الاسم</h4><textarea id="note" rows="6" placeholder="اكتب هنا...">' + esc(S.t['names:' + i] || '') + '</textarea>' +
      '<div class="actions"><button class="btn' + (v === 1 ? ' on' : '') + '" id="nm-done">' + (v === 1 ? '✓ تم' : 'تحديد كمنجز') + '</button>' +
      '<button class="btn danger" id="nm-clear">مسح الملاحظة</button><button class="btn ghost" id="nm-prev">السابق</button><button class="btn ghost" id="nm-next">التالي</button></div>' +
      '<p class="small c">' + ar(i + 1) + ' / ' + ar(NAMES.length) + '</p></article>';
    const ta = document.getElementById('note');
    ta.addEventListener('input', () => { S.t['names:' + i] = ta.value; save(); });
  }

  function renderLines(node) {
    let h = head(node) + tabs(node.pages) + '<div class="lines">';
    for (let l = 0; l < node.lines; l++) {
      const k = node.id + ':' + nav.page + ':' + l;
      h += '<div class="ln"><span>' + ar(l + 1) + '</span><input type="text" data-t="' + k + '" value="' + esc(S.t[k] || '') + '" placeholder="' + esc(node.ph || '') + '"><button class="lx" data-clr="' + k + '" aria-label="مسح">✕</button></div>';
    }
    $app.innerHTML = h + '</div>';
  }

  function renderHabit(node) {
    const hb = S.h[node.id] || { name: '', pass: '', locked: false };
    if (hb.name && hb.locked && hb.pass) {
      $app.innerHTML = '<article class="detail c"><div class="lock">🔒</div><h3>مربع مغلق</h3><p>أدخل كلمة السر لفتح المربع</p>' +
        '<input type="password" id="pw" placeholder="كلمة السر"><div class="actions"><button class="btn" id="unlock">فتح</button></div><p class="err" id="err"></p>' +
        bar(pct(counts(node))) + '<p class="small c">التقدم ' + ar(pct(counts(node))) + '٪</p></article>';
      return;
    }
    let top = '';
    if (nav.page === 0) {
      top = '<div class="habit-form"><label>اسم العادة (لا يظهر خارج هذه الشاشة)</label><input type="text" id="hname" placeholder="اكتب اسم العادة" value="' + esc(hb.name || '') + '">' +
        '<label>كلمة سر لغلق المربع (اختياري)</label><input type="password" id="hpass" placeholder="' + (hb.pass ? 'اتركها فارغة لعدم التغيير' : 'كلمة السر') + '">' +
        '<div class="actions"><button class="btn" id="hsave">' + (hb.name ? 'حفظ التعديل' : 'حفظ') + '</button>' +
        (hb.pass ? '<button class="btn ghost" id="hlock">🔒 إغلاق</button><button class="btn ghost" id="hrmpw">إزالة كلمة السر</button>' : '') +
        (hb.name || hasCells(node.id) ? '<button class="btn danger" id="hdel">🗑️ حذف العادة</button>' : '') + '</div></div>';
    }
    $app.innerHTML = head(node) + top + tabs(PAGES, true) + dayCells(node.id) + legend();
  }
  const hasCells = (id) => Object.keys(S.c).some((k) => k.indexOf(id + ':') === 0);

  function renderSetup() {
    $app.innerHTML = '<article class="detail c"><div class="lock">🗓️</div><h3>اختر تاريخ بداية الـ ٩٠ يوم</h3><p>ابدأ من اليوم الذي تريده، ويمكنك تغييره لاحقًا من الإعدادات ⚙</p>' +
      '<input type="date" id="sdate0" value="' + iso(today0()) + '">' +
      '<div class="actions"><button class="btn" id="sgo">ابدأ</button></div></article>';
  }

  function render() {
    if (!S.start) { $back.style.visibility = 'hidden'; $title.textContent = '٩٠ يوم تغيير'; document.documentElement.style.setProperty('--h', 160); document.body.className = 'home'; renderSetup(); return; }
    const node = nav.path.length ? findNode(nav.path) : null;
    const showBack = nav.path.length > 0;
    const hue = node ? node.h : 160;
    document.documentElement.style.setProperty('--h', hue);
    document.body.className = (node && node.id === 'hadith') ? 'hadith-screen' : (node ? '' : 'home');
    $back.style.visibility = showBack ? 'visible' : 'hidden';
    if (!node) { $title.textContent = '٩٠ يوم تغيير'; renderHome(); window.scrollTo(0, 0); return; }
    let t = node.type === 'habit' ? habitTitle(node) : node.title;
    if (nav.sub != null && node.type === 'names') t = 'الأسماء الحسنى';
    $title.textContent = t;
    if (node.children) renderGroup(node);
    else switch (node.type) {
      case 'days': renderDays(node); break;
      case 'dates': renderDates(node); break;
      case 'hadith': renderHadith(node); break;
      case 'names': renderNames(node); break;
      case 'lines': renderLines(node); break;
      case 'habit': renderHabit(node); break;
      case 'calendar': renderCalendar(); break;
    }
  }
  const go = () => { render(); window.scrollTo(0, 0); };


  /* ---------- التقويم الهجري والملاحظات ---------- */
  let calAnchor = today0();
  let noteDate = null;
  const hasNote = (k) => { const n = S.n[k]; return n && ((n.text && n.text.trim()) || n.rem); };
  function monthStart(a) { let d = a, g = 0; while (g++ < 40) { const h = hijri(d); if (!h || h.day <= 1) break; d = addDays(d, -1); } return d; }

  function renderCalendar() {
    if (!hfmt) { $app.innerHTML = '<p class="empty">التقويم الهجري غير مدعوم على هذا الجهاز.</p>'; return; }
    const ms = monthStart(calAnchor), h0 = hijri(ms);
    const cells = [];
    for (let i = 0; i < 31; i++) { const d = addDays(ms, i), h = hijri(d); if (!h || h.month !== h0.month) break; cells.push({ d, h }); }
    const last = cells[cells.length - 1].d, ti = iso(today0());
    const gm = (d) => ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'][d.getMonth()] + ' ' + ar(d.getFullYear());
    let h = '<div class="cal-head"><button class="btn ghost" data-cal-nav="prev" aria-label="الشهر السابق">›</button><div class="cal-title"><b>' + HMONTHS[h0.month - 1] + ' ' + ar(h0.year) + 'هـ</b><small>' +
      gm(ms) + (gm(last) !== gm(ms) ? ' — ' + gm(last) : '') + '</small></div><button class="btn ghost" data-cal-nav="next" aria-label="الشهر التالي">‹</button></div>' +
      '<div class="actions"><button class="btn ghost" data-cal-nav="today">اليوم</button></div>';
    h += '<div class="cal-grid">' + WEEK.map((w) => '<div class="wd">' + w.replace('ال', '') + '</div>').join('');
    for (let i = 0; i < ms.getDay(); i++) h += '<div></div>';
    cells.forEach((c) => {
      const k = iso(c.d), n = S.n[k];
      h += '<button class="cd' + (k === ti ? ' today' : '') + (c.d.getDay() === 5 ? ' fri' : '') + '" data-cal="' + k + '"><b>' + ar(c.h.day) + '</b><em>' + ar(c.d.getDate()) + '</em>' +
        (hasNote(k) ? '<i class="dot' + (n.rem ? ' bell' : '') + '"></i>' : '') + '</button>';
    });
    h += '</div><div class="hadj"><span>تصحيح التقويم الهجري (حسب رؤية الهلال):</span><div><button class="btn ghost" data-hadj="-1">−</button><b>' +
      (S.hadj > 0 ? '+' : '') + ar(S.hadj) + ' يوم</b><button class="btn ghost" data-hadj="1">+</button></div></div>' +
      '<p class="legend">اضغط على أي يوم لكتابة ملاحظة وضبط تنبيه. النقطة الذهبية = ملاحظة، 🔔 = ملاحظة بتنبيه.</p>';
    const upcoming = Object.keys(S.n).filter((k) => hasNote(k) && k >= ti).sort().slice(0, 10);
    if (upcoming.length) {
      h += '<h4 class="up">الملاحظات القادمة</h4><div class="list">';
      upcoming.forEach((k) => { const d = parseISO(k), hj = hijri(d), n = S.n[k];
        h += '<button class="row" data-cal="' + k + '"><span class="rt">' + esc((n.text || 'تذكير').slice(0, 60)) + '<small>' + WEEK[d.getDay()] + ' ' + ar(d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear()) +
          (hj ? ' — ' + ar(hj.day) + ' ' + HMONTHS[hj.month - 1] : '') + (n.rem ? ' — 🔔 ' + ar(n.time) : '') + '</small></span></button>'; });
      h += '</div>';
    }
    $app.innerHTML = h;
  }

  const notifId = (k) => parseInt(k.replace(/-/g, ''), 10);
  function schedule(k, n) {
    if (!window.Android || !window.Android.schedule) return;
    const id = notifId(k);
    if (n && n.rem && n.time) {
      const [y, m, d] = k.split('-').map(Number), [hh, mm] = n.time.split(':').map(Number);
      window.Android.schedule(id, String(new Date(y, m - 1, d, hh, mm, 0).getTime()), 'تذكير — ٩٠ يوم تغيير', (n.text || '').trim() || 'لديك تذكير');
    } else window.Android.cancel(id);
  }

  function openNote(k) {
    noteDate = k; const d = parseISO(k), hj = hijri(d), n = S.n[k] || {};
    modal = true; $modal.hidden = false;
    $modal.innerHTML = '<div class="sheet"><h3>' + WEEK[d.getDay()] + ' ' + ar(d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear()) + '</h3>' +
      '<p class="small">' + (hj ? ar(hj.day) + ' ' + HMONTHS[hj.month - 1] + ' ' + ar(hj.year) + 'هـ' : '') + '</p>' +
      '<label>الملاحظة</label><textarea id="ntext" rows="5" placeholder="اكتب ملاحظتك...">' + esc(n.text || '') + '</textarea>' +
      '<label class="chkrow"><input type="checkbox" id="nrem"' + (n.rem ? ' checked' : '') + '> تنبيه على شاشة الهاتف</label>' +
      '<label>وقت التنبيه</label><input type="time" id="ntime" value="' + (n.time || '09:00') + '">' +
      '<div class="actions"><button class="btn" id="nsave">حفظ</button><button class="btn danger" id="ndel">حذف</button><button class="btn ghost" id="nclose">إغلاق</button></div></div>';
  }

  function saveNote() {
    const k = noteDate, text = document.getElementById('ntext').value, rem = document.getElementById('nrem').checked, time = document.getElementById('ntime').value || '09:00';
    if (rem) {
      const [y, m, d] = k.split('-').map(Number), [hh, mm] = time.split(':').map(Number);
      if (new Date(y, m - 1, d, hh, mm).getTime() <= Date.now()) { alert('وقت التنبيه في الماضي، اختر وقتًا قادمًا.'); return; }
    }
    if (!text.trim() && !rem) { delete S.n[k]; schedule(k, null); } else { S.n[k] = { text, rem, time }; schedule(k, S.n[k]); }
    save(); closeModal(); render();
  }
  function delNote() { delete S.n[noteDate]; schedule(noteDate, null); save(); closeModal(); render(); }


  /* ---------- تصدير تقرير PDF ---------- */
  const markG = (v) => (v === 1 ? '✓' : v === 2 ? '✗' : '·');
  const mcls = (v) => (v === 1 ? 'ok' : v === 2 ? 'no' : '');

  function leafHTML(node) {
    let h = '';
    switch (node.type) {
      case 'days': case 'habit': {
        const st = parseISO(S.start); h += '<div class="g">';
        for (let i = 0; i < DAYS; i++) { const v = S.c[node.id + ':' + i] || 0, d = addDays(st, i);
          h += '<span class="' + mcls(v) + '"><b>' + ar(i + 1) + '</b><i>' + ar(d.getDate() + '/' + (d.getMonth() + 1)) + '</i><u>' + markG(v) + '</u></span>'; }
        return h + '</div>'; }
      case 'dates': {
        h += '<div class="g w">';
        dateList(node.kind).forEach((x) => { const v = S.c[node.id + ':' + x.k] || 0;
          h += '<span class="' + mcls(v) + '"><b>' + WEEK[x.d.getDay()] + '</b><i>' + ar(x.d.getDate() + '/' + (x.d.getMonth() + 1) + '/' + x.d.getFullYear()) + '</i>' +
            '<i>' + (x.h ? ar(x.h.day) + ' ' + HMONTHS[x.h.month - 1] : '') + (x.bayd ? ' (بيض)' : '') + '</i><u>' + markG(v) + '</u></span>'; });
        return h + '</div>'; }
      case 'hadith':
        h += '<table>';
        for (let i = 0; i < DAYS; i++) { const v = S.c['hadith:' + i] || 0; h += '<tr class="' + mcls(v) + '"><td class="n">' + ar(i + 1) + '</td><td>' + esc(HADITHS[i] || '') + '</td><td class="m">' + markG(v) + '</td></tr>'; }
        return h + '</table>';
      case 'names':
        h += '<table>';
        NAMES.forEach((n, i) => { const v = S.c['names:' + i] || 0, t = (S.t['names:' + i] || '').trim();
          h += '<tr class="' + mcls(v) + '"><td class="n">' + ar(i + 1) + '</td><td><b>' + esc(n[0]) + '</b>' + (t ? '<div class="nt">' + esc(t) + '</div>' : '') + '</td><td class="m">' + markG(v) + '</td></tr>'; });
        return h + '</table>';
      case 'lines': {
        let any = false; h += '<ol class="ls">';
        for (let p = 0; p < node.pages; p++) for (let l = 0; l < node.lines; l++) { const t = (S.t[node.id + ':' + p + ':' + l] || '').trim(); if (t) { any = true; h += '<li>' + esc(t) + '</li>'; } }
        return h + (any ? '' : '<li class="emp">لا توجد بيانات</li>') + '</ol>'; }
    }
    return h;
  }

  function nodeHTML(node, depth) {
    const r = counts(node), p = pct(r);
    let title = node.title;
    const tag = 'h' + (depth + 2);
    let h = '<section class="' + (depth === 0 ? 'top' : 'sub') + '" style="--h:' + node.h + '"><' + tag + '>' + esc(title) + '<small>' + ar(p) + '٪ (' + ar(r.done) + ' من ' + ar(r.total) + ')</small></' + tag + '>';
    if (node.children) node.children.forEach((c) => { h += nodeHTML(c, depth + 1); });
    else h += leafHTML(node);
    return h + '</section>';
  }

  function buildReport() {
    let done = 0, total = 0;
    TREE.forEach((n) => { if (n.type === 'calendar') return; const r = counts(n); done += r.done; total += r.total; });
    const td = today0(), th = hijri(td), st = parseISO(S.start);
    let h = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>' + REPORT_CSS + '</style></head><body>' +
      '<header><h1>٩٠ يوم تغيير — التقرير</h1><p>بداية التحدي: ' + ar(st.getDate() + '/' + (st.getMonth() + 1) + '/' + st.getFullYear()) + ' — تاريخ التقرير: ' +
      (th ? ar(th.day) + ' ' + HMONTHS[th.month - 1] + ' ' + ar(th.year) + 'هـ — ' : '') + ar(td.getDate() + '/' + (td.getMonth() + 1) + '/' + td.getFullYear()) + '</p>' +
      '<p class="big">الإنجاز الكلي: ' + ar(pct({ done, total })) + '٪</p><table class="sum">';
    TREE.forEach((n) => { if (n.type === 'calendar') return; h += '<tr style="--h:' + n.h + '"><td>' + esc(n.title) + '</td><td>' + ar(pct(counts(n))) + '٪</td></tr>'; });
    h += '</table></header>';
    TREE.forEach((n) => {
      if (n.type === 'calendar') {
        const ks = Object.keys(S.n).filter(hasNote).sort();
        h += '<section class="top" style="--h:' + n.h + '"><h2>ملاحظات التقويم</h2>' + (ks.length ? '<table>' : '<p class="emp">لا توجد ملاحظات</p>');
        ks.forEach((k) => { const d = parseISO(k), hj = hijri(d), x = S.n[k];
          h += '<tr><td class="n">' + WEEK[d.getDay()] + '<br>' + ar(d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear()) + (hj ? '<br>' + ar(hj.day) + ' ' + HMONTHS[hj.month - 1] : '') + '</td><td>' + esc(x.text || '') + (x.rem ? '<div class="nt">🔔 ' + ar(x.time) + '</div>' : '') + '</td></tr>'; });
        h += (ks.length ? '</table>' : '') + '</section>';
      } else h += nodeHTML(n, 0);
    });
    return h + '</body></html>';
  }

  const REPORT_CSS = '*{box-sizing:border-box}body{font-family:"Noto Naskh Arabic","Noto Sans Arabic",Tahoma,sans-serif;color:#1d2b26;margin:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}' +
    '@page{size:A4;margin:12mm}header{text-align:center;margin-bottom:10px}h1{margin:0 0 4px;color:#0f5c4a}p{margin:3px 0}.big{font-size:18px;font-weight:700}' +
    '.sum{width:100%;border-collapse:collapse;margin-top:8px}.sum td{padding:5px 10px;border:1px solid #ccc;background:hsl(var(--h) 55% 88%)}.sum td:last-child{width:70px;text-align:center;font-weight:700}' +
    'section.top{page-break-before:always}h2{background:hsl(var(--h) 60% 32%);color:#fff;padding:6px 10px;border-radius:8px;margin:0 0 8px;font-size:18px}' +
    'h3,h4{background:hsl(var(--h) 50% 85%);color:hsl(var(--h) 60% 22%);padding:4px 10px;border-radius:6px;margin:10px 0 6px;font-size:15px;page-break-after:avoid}h2 small,h3 small,h4 small{float:left;font-size:12px;font-weight:400}' +
    '.g{display:flex;flex-wrap:wrap;gap:3px}.g span{width:9.4%;border:1px solid #bbb;border-radius:4px;text-align:center;padding:2px 0;background:#f3f0e2;font-size:11px;position:relative;page-break-inside:avoid}' +
    '.g.w span{width:24%;font-size:11px;padding:4px 2px}.g b{display:block;font-size:12px}.g i{display:block;font-style:normal;font-size:8px;color:#555}.g u{display:block;text-decoration:none;font-weight:800;font-size:13px}' +
    '.ok{background:#b9e8c9!important}.no{background:#f5bdb6!important}table{width:100%;border-collapse:collapse;font-size:12px}td{border:1px solid #ccc;padding:4px 6px;vertical-align:top}' +
    'td.n{width:40px;text-align:center;font-weight:700}td.m{width:34px;text-align:center;font-weight:800}tr{page-break-inside:avoid}.nt{color:#555;font-size:11px;margin-top:2px}.emp{color:#777}.ls{font-size:13px;line-height:1.8}';

  function exportPDF() { pdfPrint(); }
  function pdfPrint() {
    const html = buildReport();
    if (window.Android && window.Android.printHtml) { window.Android.printHtml(html); return; }
    const w = window.open('', '_blank');
    if (!w) { alert('افتح الملف في متصفح كروم لتتمكن من الطباعة'); return; }
    w.document.write(html); w.document.close(); setTimeout(() => w.print(), 400);
  }
  window.__buildReport = buildReport;

  /* ---------- الأحداث ---------- */
  function refreshHead() {
    const node = findNode(nav.path); if (!node) return;
    const r = counts(node), p = pct(r), el = document.querySelector('.sect-head');
    if (el) el.innerHTML = bar(p) + '<div class="small">التقدم ' + ar(p) + '٪ (' + ar(r.done) + ' من ' + ar(r.total) + ')</div>';
  }

  $app.addEventListener('click', (e) => {
    const t = e.target.closest('button'); if (!t) return;
    const d = t.dataset;
    if (d.open) { nav.path.push(d.open); nav.page = 0; nav.sub = null; go(); return; }
    if (d.page !== undefined) { nav.page = +d.page; render(); window.scrollTo(0, 0); return; }
    if (d.k) {
      const v = ((S.c[d.k] || 0) + 1) % 3; S.c[d.k] = v; if (!v) delete S.c[d.k]; save();
      t.classList.remove('ok', 'no'); if (v === 1) t.classList.add('ok'); if (v === 2) t.classList.add('no');
      if (t.classList.contains('chk')) { t.textContent = cellMark(v) || '○'; t.parentElement.classList.remove('ok', 'no'); if (v === 1) t.parentElement.classList.add('ok'); if (v === 2) t.parentElement.classList.add('no'); }
      else { const m = t.querySelector('.mk'); if (m) m.textContent = cellMark(v); }
      refreshHead(); return;
    }
    if (d.calNav) {
      const ms = monthStart(calAnchor);
      calAnchor = d.calNav === 'today' ? today0() : d.calNav === 'next' ? addDays(ms, 30) : addDays(ms, -1);
      render(); return;
    }
    if (d.cal) { openNote(d.cal); return; }
    if (d.hadj) { S.hadj = Math.max(-3, Math.min(3, (S.hadj || 0) + (+d.hadj))); save(); render(); return; }
    if (d.ex !== undefined) { const pn = t.closest('.hrow').querySelector('.ex'); pn.hidden = !pn.hidden; return; }
    if (d.clr) {
      delete S.t[d.clr]; save();
      const inp = t.parentElement.querySelector('input'); if (inp) inp.value = '';
      refreshHead(); return;
    }
    if (d.name !== undefined) { nav.sub = +d.name; render(); window.scrollTo(0, 0); return; }
    const node = findNode(nav.path);
    switch (t.id) {
      case 'pdfexp': exportPDF(); break;
      case 'sgo': { const v = document.getElementById('sdate0').value; if (!v) { alert('اختر تاريخًا'); return; } S.start = v; save(); nav = { path: [], page: 0, sub: null }; go(); break; }
      case 'nm-done': { const k = 'names:' + nav.sub; if (S.c[k] === 1) delete S.c[k]; else S.c[k] = 1; save(); render(); break; }
      case 'nm-clear': delete S.t['names:' + nav.sub]; save(); render(); break;
      case 'nm-prev': nav.sub = (nav.sub + NAMES.length - 1) % NAMES.length; go(); break;
      case 'nm-next': nav.sub = (nav.sub + 1) % NAMES.length; go(); break;
      case 'hsave': {
        const n = document.getElementById('hname').value.trim(), p = document.getElementById('hpass').value;
        if (!n) { alert('اكتب اسم العادة'); return; }
        const old = S.h[node.id] || {};
        const pass = p || old.pass || '';
        S.h[node.id] = { name: n, pass, locked: !!pass && !old.name }; // أول حفظ بكلمة سر يغلق المربع، والتعديل يبقيه مفتوحًا
        save(); nav.page = 0; go(); break; }
      case 'hlock': S.h[node.id].locked = true; save(); go(); break;
      case 'hrmpw': S.h[node.id].pass = ''; S.h[node.id].locked = false; save(); go(); break;
      case 'hdel':
        if (confirm('حذف العادة وكل علاماتها؟')) {
          delete S.h[node.id];
          Object.keys(S.c).forEach((k) => { if (k.indexOf(node.id + ':') === 0) delete S.c[k]; });
          save(); nav.page = 0; go();
        }
        break;
      case 'unlock': {
        const p = document.getElementById('pw').value;
        if (S.h[node.id] && p === S.h[node.id].pass) { S.h[node.id].locked = false; save(); go(); }
        else document.getElementById('err').textContent = 'كلمة السر غير صحيحة';
        break; }
    }
  });
  $app.addEventListener('input', (e) => {
    const k = e.target.dataset && e.target.dataset.t;
    if (k) { S.t[k] = e.target.value; save(); refreshHead(); }
  });

  $back.addEventListener('click', () => { back(); });
  function back() {
    if (modal) { closeModal(); return true; }
    if (nav.sub != null) { nav.sub = null; render(); return true; }
    if (nav.path.length) { nav.path.pop(); nav.page = 0; go(); return true; }
    return false;
  }
  window.__back = () => back();

  /* ---------- الإعدادات ---------- */
  function openModal() {
    modal = true; $modal.hidden = false;
    $modal.innerHTML = '<div class="sheet"><h3>الإعدادات</h3>' +
      '<label>تاريخ بداية الـ ٩٠ يوم</label><input type="date" id="sdate" value="' + (S.start || '') + '">' +
      '<div class="actions"><button class="btn" id="ssave">حفظ</button></div><hr>' +
      '<div class="actions"><button class="btn" id="pdfexp">📄 تصدير تقرير PDF</button></div>' +
      '<div class="actions"><button class="btn danger" id="sreset">مسح كل البيانات</button></div>' +
      '<div class="actions"><button class="btn ghost" id="sclose">إغلاق</button></div></div>';
  }
  function closeModal() { modal = null; $modal.hidden = true; $modal.innerHTML = ''; }
  $gear.addEventListener('click', openModal);
  $modal.addEventListener('click', (e) => {
    if (e.target === $modal) { closeModal(); return; }
    const id = e.target.id;
    if (id === 'pdfexp') { closeModal(); exportPDF(); }
    else if (id === 'sclose' || id === 'nclose') closeModal();
    else if (id === 'nsave') saveNote();
    else if (id === 'ndel') delNote();
    else if (id === 'ssave') { const v = document.getElementById('sdate').value; if (v) { S.start = v; save(); } closeModal(); go(); }
    else if (id === 'sreset') {
      if (confirm('سيتم مسح كل البيانات نهائيًا. متأكد؟')) { S = { start: null, c: {}, t: {}, h: {}, n: {}, hadj: 0 }; save(); closeModal(); nav = { path: [], page: 0, sub: null }; go(); }
    }
  });

  render();
})();
