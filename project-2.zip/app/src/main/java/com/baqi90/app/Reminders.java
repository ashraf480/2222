package com.baqi90.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.Map;

/** جدولة التنبيهات وحفظها لإعادة جدولتها بعد إعادة تشغيل الهاتف. */
public class Reminders {
    private static final String PREFS = "reminders";

    static PendingIntent pi(Context c, int id, String title, String body) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        return PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void schedule(Context c, int id, long millis, String title, String body) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(String.valueOf(id), millis + "\n" + title + "\n" + body).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = pi(c, id, title, body);
        if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, p);
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, p);
        }
    }

    public static void cancel(Context c, int id) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(String.valueOf(id)).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pi(c, id, "", ""));
    }

    public static void forget(Context c, int id) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(String.valueOf(id)).apply();
    }

    public static void rescheduleAll(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
            try {
                String[] p = ((String) e.getValue()).split("\n", 3);
                long t = Long.parseLong(p[0]);
                if (t > System.currentTimeMillis()) {
                    schedule(c, Integer.parseInt(e.getKey()), t, p[1], p.length > 2 ? p[2] : "");
                } else {
                    forget(c, Integer.parseInt(e.getKey()));
                }
            } catch (Exception ignored) { }
        }
    }
}
